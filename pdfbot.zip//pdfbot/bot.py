import os
import re
import json
import time
import threading
import subprocess
import requests

BASE = os.path.expanduser("~/pdfbot")
CONFIG = os.path.join(BASE, "config.txt")
STATE = os.path.join(BASE, "estado.json")
PDF_DIR = "/storage/emulated/0/Doujinshi /Bot de telegram"
COVERS = os.path.join(BASE, "portadas")
LOGS = os.path.join(BASE, "logs")

os.makedirs(COVERS, exist_ok=True)
os.makedirs(LOGS, exist_ok=True)

def read_config():
    data = {}
    with open(CONFIG, encoding="utf-8") as f:
        for line in f:
            if "=" in line:
                k, v = line.strip().split("=", 1)
                data[k] = v
    return data

cfg = read_config()
TOKEN = open(os.path.join(BASE, "token.txt")).read().strip()
CHANNEL = cfg["CANAL"]
ADMIN = int(cfg["ADMIN_ID"])
API = f"https://api.telegram.org/bot{TOKEN}/"

stop_event = threading.Event()
worker = None
lock = threading.Lock()

try:
    with open(STATE, encoding="utf-8") as f:
        state = json.load(f)
except Exception:
    state = {}

def save_state():
    tmp = STATE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)
    os.replace(tmp, STATE)

def api(method, data=None, files=None, timeout=300):
    r = requests.post(API + method, data=data, files=files, timeout=timeout)
    result = r.json()
    if not result.get("ok"):
        raise RuntimeError(result.get("description", "Error de Telegram"))
    return result["result"]

def message(chat, text):
    return api("sendMessage", {"chat_id": chat, "text": text})

def admin_message(text):
    try:
        message(ADMIN, text)
    except Exception as e:
        print("Error avisando al administrador:", e)

def file_key(path):
    s = os.stat(path)
    return f"{path}|{s.st_size}|{s.st_mtime_ns}"

def render_cover(pdf, output):
    prefix = output[:-4] if output.lower().endswith(".jpg") else output
    subprocess.run(
        ["pdftoppm", "-f", "1", "-l", "1", "-jpeg",
         "-singlefile", "-scale-to", "1600", pdf, prefix],
        check=True, stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE, timeout=180
    )
    if not os.path.isfile(output):
        raise RuntimeError("No se generó la portada")

def send_photo(path, name):
    with open(path, "rb") as f:
        api("sendPhoto", data={
            "chat_id": CHANNEL,
            "caption": "📖 " + name[:900]
        }, files={"photo": (os.path.basename(path), f, "image/jpeg")})

def send_pdf(path, name):
    with open(path, "rb") as f:
        api("sendDocument", data={
            "chat_id": CHANNEL,
            "caption": name[:900]
        }, files={"document": (name, f, "application/pdf")})

def process_pdfs():
    global state
    stop_event.clear()

    pdfs = sorted(
        os.path.join(PDF_DIR, x)
        for x in os.listdir(PDF_DIR)
        if x.lower().endswith(".pdf")
        and os.path.isfile(os.path.join(PDF_DIR, x))
    )

    total = len(pdfs)
    done = 0
    skipped = 0
    errors = 0

    admin_message(f"🚀 Procesamiento iniciado. Encontrados: {total} PDF.")

    for index, pdf in enumerate(pdfs, 1):
        if stop_event.is_set():
            break

        name = os.path.basename(pdf)
        key = file_key(pdf)
        entry = state.get(key, {})
        size = os.path.getsize(pdf)

        if size > 50 * 1024 * 1024:
            skipped += 1
            entry["status"] = "supera_50MB"
            state[key] = entry
            save_state()
            print("Pendiente por tamaño:", name)
            continue

        if entry.get("photo") and entry.get("document"):
            done += 1
            continue

        cover = os.path.join(COVERS, name + ".jpg")

        try:
            if not entry.get("photo"):
                if not os.path.exists(cover):
                    render_cover(pdf, cover)
                send_photo(cover, name)
                entry["photo"] = True
                state[key] = entry
                save_state()

            if stop_event.is_set():
                break

            if not entry.get("document"):
                send_pdf(pdf, name)
                entry["document"] = True
                state[key] = entry
                save_state()

            done += 1
            print(f"[{index}/{total}] Publicado: {name}")

        except Exception as e:
            errors += 1
            entry["error"] = str(e)
            state[key] = entry
            save_state()
            print("ERROR:", name, e)

        if index % 5 == 0:
            admin_message(
                f"📊 Revisados: {index}/{total}\n"
                f"Completados: {done}\n"
                f"Pendientes por tamaño: {skipped}\n"
                f"Errores: {errors}"
            )

    if stop_event.is_set():
        result = "⏸ Procesamiento detenido. Puedes reanudarlo con /procesar."
    else:
        result = "✅ Procesamiento finalizado."

    admin_message(
        f"{result}\n"
        f"Completados en esta ejecución: {done}\n"
        f"Superiores a 50 MB: {skipped}\n"
        f"Errores: {errors}"
    )

def start_worker():
    global worker
    if worker and worker.is_alive():
        return False
    stop_event.clear()
    worker = threading.Thread(target=process_pdfs, daemon=True)
    worker.start()
    return True

def handle_command(text):
    cmd = text.split()[0].split("@")[0].lower()

    if cmd == "/start" or cmd == "/iniciar":
        message(ADMIN,
            "🤖 PDF Bot Miniaturas está listo.\n\n"
            "/procesar - Procesar los PDF\n"
            "/estado - Consultar estado\n"
            "/detener - Detener el proceso"
        )

    elif cmd == "/procesar":
        if start_worker():
            message(ADMIN, "▶️ Procesamiento solicitado.")
        else:
            message(ADMIN, "Ya hay un procesamiento en marcha.")

    elif cmd == "/detener":
        stop_event.set()
        message(ADMIN, "⏸ Solicitud de detención recibida.")

    elif cmd == "/estado":
        running = bool(worker and worker.is_alive())
        total = sum(
            1 for x in state.values()
            if x.get("photo") and x.get("document")
        )
        message(ADMIN,
            f"Estado: {'Procesando' if running else 'En espera'}\n"
            f"PDF completados registrados: {total}\n"
            f"Archivos en carpeta: {len([x for x in os.listdir(PDF_DIR) if x.lower().endswith('.pdf')])}"
        )

def main():
    me = api("getMe")
    print("Bot conectado:", me["username"])

    # Evita procesar mensajes antiguos al arrancar
    updates = api("getUpdates", {"offset": -1, "timeout": 1})
    offset = updates[-1]["update_id"] + 1 if updates else 0

    admin_message("🤖 Bot iniciado y conectado correctamente.")

    while True:
        try:
            updates = api("getUpdates", {
                "offset": offset,
                "timeout": 30,
                "allowed_updates": json.dumps(["message"])
            }, timeout=40)

            for update in updates:
                offset = update["update_id"] + 1
                msg = update.get("message", {})
                user = msg.get("from", {})
                text = msg.get("text", "")

                if user.get("id") == ADMIN and text.startswith("/"):
                    handle_command(text)

        except KeyboardInterrupt:
            stop_event.set()
            break
        except Exception as e:
            print("Error de conexión:", e)
            time.sleep(5)

if __name__ == "__main__":
    main()
