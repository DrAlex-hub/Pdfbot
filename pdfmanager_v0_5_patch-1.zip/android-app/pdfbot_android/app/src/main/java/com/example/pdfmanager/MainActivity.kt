package com.example.pdfmanager

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var summary: TextView
    private lateinit var search: EditText
    private lateinit var fileList: LinearLayout
    private val prefs by lazy { getSharedPreferences(PdfScanService.PREFS, MODE_PRIVATE) }
    private val folderPicker = 4102
    private val preferenceListener =
        android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
            if (::summary.isInitialized) refreshCatalog()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 28)
        }
        val title = TextView(this).apply {
            text = "PDF Manager"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Catálogo local de documentos PDF. Explora carpetas y subcarpetas, consulta tamaños y abre tus archivos."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 20)
        }
        status = TextView(this).apply {
            textSize = 15f
            setPadding(0, 8, 0, 12)
        }
        summary = TextView(this).apply {
            textSize = 14f
            setPadding(0, 8, 0, 12)
        }
        val choose = Button(this).apply {
            text = "Seleccionar carpeta"
            setOnClickListener { chooseFolder() }
        }
        val start = Button(this).apply {
            text = "Actualizar catálogo"
            setOnClickListener { startScan() }
        }
        val stop = Button(this).apply {
            text = "Detener proceso"
            setOnClickListener { stopScan() }
        }
        search = EditText(this).apply {
            hint = "Buscar por nombre…"
            singleLine = true
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    renderFiles()
                }
                override fun afterTextChanged(s: android.text.Editable?) = Unit
            })
        }
        val listTitle = TextView(this).apply {
            text = "DOCUMENTOS"
            textSize = 13f
            setPadding(0, 18, 0, 8)
        }
        fileList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        content.addView(title, matchWrap())
        content.addView(subtitle, matchWrap())
        content.addView(status, matchWrap())
        content.addView(choose, matchWrap())
        content.addView(start, matchWrap())
        content.addView(stop, matchWrap())
        content.addView(summary, matchWrap())
        content.addView(search, matchWrap())
        content.addView(listTitle, matchWrap())
        content.addView(fileList, matchWrap())
        setContentView(ScrollView(this).apply { addView(content) })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 4103)
        }
        refreshStatus()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun chooseFolder() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), folderPicker)
    }

    @Deprecated("Deprecated by platform; retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == folderPicker && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val flags = data.flags and
                (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            try {
                contentResolver.takePersistableUriPermission(uri, flags)
                prefs.edit().putString("folder_uri", uri.toString()).apply()
                refreshStatus()
            } catch (e: SecurityException) {
                status.text = "No se pudo conservar el acceso: ${e.message}"
            }
        }
    }

    private fun startScan() {
        val uriText = prefs.getString("folder_uri", null)
        if (uriText == null) {
            status.text = "Primero selecciona una carpeta."
            return
        }
        val serviceIntent = Intent(this, PdfScanService::class.java)
            .setAction(PdfScanService.ACTION_START)
            .putExtra(PdfScanService.EXTRA_FOLDER_URI, uriText)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            status.text = "Catálogo en ejecución. El progreso continúa en la notificación."
        } catch (e: Exception) {
            status.text = "No se pudo iniciar: ${e.message ?: "comprueba los permisos"}"
        }
    }

    private fun stopScan() {
        startService(Intent(this, PdfScanService::class.java).setAction(PdfScanService.ACTION_STOP))
        status.text = "Solicitud de detención enviada."
    }

    private fun refreshStatus() {
        val uriText = prefs.getString("folder_uri", null)
        val folder = uriText?.let { DocumentFile.fromTreeUri(this, Uri.parse(it)) }
        status.text = if (folder != null) {
            "Carpeta: ${folder.name ?: "Documentos"}"
        } else {
            "Selecciona la carpeta que contiene tus PDF."
        }
        refreshCatalog()
    }

    private fun refreshCatalog() {
        val count = prefs.getInt(PdfScanService.KEY_LAST_COUNT, -1)
        val total = prefs.getInt(PdfScanService.KEY_LAST_TOTAL, -1)
        val bytes = prefs.getLong(PdfScanService.KEY_LAST_BYTES, 0L)
        val time = prefs.getLong(PdfScanService.KEY_LAST_TIME, 0L)
        val lastStatus = prefs.getString(PdfScanService.KEY_LAST_STATUS, null)
        val truncated = prefs.getBoolean(PdfScanService.KEY_LAST_TRUNCATED, false)
        summary.text = if (count >= 0 && time > 0) {
            buildString {
                append("Estado: ${lastStatus ?: "Sin estado"}\n")
                append("PDF catalogados: $count de ${total.coerceAtLeast(count)}\n")
                append("Tamaño total: ${formatBytes(bytes)}\n")
                append("Última actualización: ${DateFormat.getDateTimeInstance().format(Date(time))}")
                if (truncated) append("\nSe muestran los primeros 5.000 archivos.")
            }
        } else {
            "Todavía no hay catálogo. Pulsa «Actualizar catálogo»."
        }
        renderFiles()
    }

    private fun renderFiles() {
        if (!::fileList.isInitialized) return
        fileList.removeAllViews()
        val raw = prefs.getString(PdfScanService.KEY_LAST_FILES, "[]") ?: "[]"
        val files = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val query = if (::search.isInitialized) search.text.toString().trim().lowercase(Locale.getDefault()) else ""
        var shown = 0
        for (i in 0 until files.length()) {
            val item = files.optJSONObject(i) ?: continue
            val name = item.optString("name", "Documento PDF")
            if (query.isNotEmpty() && !name.lowercase(Locale.getDefault()).contains(query)) continue
            val uri = item.optString("uri")
            val size = item.optLong("size", 0L)
            val modified = item.optLong("modified", 0L)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
                isClickable = true
                isFocusable = true
                setOnClickListener { openPdf(uri) }
            }
            val nameView = TextView(this).apply {
                text = name
                textSize = 15f
            }
            val details = TextView(this).apply {
                text = "${formatBytes(size)}  •  " +
                    if (modified > 0) DateFormat.getDateTimeInstance().format(Date(modified)) else "Fecha no disponible"
                textSize = 12f
                setTextColor(0xffb3261e.toInt())
                setPadding(0, 5, 0, 0)
            }
            row.addView(nameView, matchWrap())
            row.addView(details, matchWrap())
            val params = matchWrap().apply { bottomMargin = 10 }
            fileList.addView(row, params)
            shown++
        }
        if (shown == 0) {
            fileList.addView(TextView(this).apply {
                text = if (files.length() == 0) "No hay documentos catalogados." else "No hay coincidencias."
                textSize = 14f
                setPadding(0, 12, 0, 20)
            }, matchWrap())
        } else {
            fileList.addView(TextView(this).apply {
                text = "Mostrando $shown documento(s). Toca uno para abrirlo."
                textSize = 12f
                setPadding(0, 8, 0, 16)
            }, matchWrap())
        }
    }

    private fun openPdf(uriText: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.parse(uriText), "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (_: Exception) {
            status.text = "No hay una aplicación instalada para abrir PDF."
        }
    }

    private fun formatBytes(value: Long): String {
        if (value < 1024) return "$value B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var size = value.toDouble()
        var unit = -1
        do {
            size /= 1024.0
            unit++
        } while (size >= 1024 && unit < units.lastIndex)
        return String.format(Locale.getDefault(), "%.2f %s", size, units[unit])
    }

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(preferenceListener)
        if (::status.isInitialized) refreshStatus()
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(preferenceListener)
        super.onPause()
    }
}
